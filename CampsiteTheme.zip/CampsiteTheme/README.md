Example of CSS plugin
=====================

This plugin add a new stylesheet and override default styles.

Installation
------------

- Create a directory **Css** under the folder **plugins**
- Copy all source files into this new directory

Author
------

The example stylesheet come from the [issue #1248](https://github.com/fguillot/kanboard/issues/1248) created by @oliverh72

Screenshot
----------

![plugin-css](https://cloud.githubusercontent.com/assets/323546/10009045/ff659ec4-60a4-11e5-9af3-c63a1bef58d6.png)
